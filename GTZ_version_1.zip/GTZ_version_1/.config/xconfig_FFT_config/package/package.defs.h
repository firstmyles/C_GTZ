/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z52
 */

#ifndef xconfig_FFT_config__
#define xconfig_FFT_config__



#endif /* xconfig_FFT_config__ */ 
